from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="IncomeResponse")


@_attrs_define
class IncomeResponse:
    """
    Attributes:
        predicted_yearly_income (float): Predicted yearly income of the customer. Example: 48000.75.
    """

    predicted_yearly_income: float
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        predicted_yearly_income = self.predicted_yearly_income

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "predicted_yearly_income": predicted_yearly_income,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        predicted_yearly_income = d.pop("predicted_yearly_income")

        income_response = cls(
            predicted_yearly_income=predicted_yearly_income,
        )

        income_response.additional_properties = d
        return income_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
