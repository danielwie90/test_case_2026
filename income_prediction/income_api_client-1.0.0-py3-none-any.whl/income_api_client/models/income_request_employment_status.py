from enum import Enum


class IncomeRequestEmploymentStatus(str, Enum):
    EMPLOYED = "employed"
    STUDENT = "student"
    UNEMPLOYED = "unemployed"

    def __str__(self) -> str:
        return str(self.value)
