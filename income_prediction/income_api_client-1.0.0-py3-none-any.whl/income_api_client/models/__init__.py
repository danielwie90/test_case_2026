"""Contains all the data models used in inputs/outputs"""

from .income_request import IncomeRequest
from .income_request_employment_status import IncomeRequestEmploymentStatus
from .income_response import IncomeResponse

__all__ = (
    "IncomeRequest",
    "IncomeRequestEmploymentStatus",
    "IncomeResponse",
)
