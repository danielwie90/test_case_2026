from __future__ import annotations

import re
from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.income_request_employment_status import IncomeRequestEmploymentStatus

T = TypeVar("T", bound="IncomeRequest")


@_attrs_define
class IncomeRequest:
    """
    Attributes:
        customer_id (str): Unique identifier for the customer. Example: 01010199999.
        period (str): Period in YYYYMM format. Example: 202301.
        age (int): Age of the customer. Example: 30.
        employment_status (IncomeRequestEmploymentStatus): Employment status of the customer. Example: employed.
        income_month (float): Monthly income of the customer. Example: 4000.5.
    """

    customer_id: str
    period: str
    age: int
    employment_status: IncomeRequestEmploymentStatus
    income_month: float
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        customer_id = self.customer_id

        period = self.period

        age = self.age

        employment_status = self.employment_status.value

        income_month = self.income_month

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "customer_id": customer_id,
                "period": period,
                "age": age,
                "employment_status": employment_status,
                "income_month": income_month,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        customer_id = d.pop("customer_id")
        if not isinstance(customer_id, str):
            raise TypeError(
                f"Expected type 'str' for field 'customer_id', got '{type(customer_id).__name__}'"
            )
        if not re.match(r"^\d{11}$", customer_id):
            raise ValueError("customer_id must consist of exactly 11 digits (0-9)")

        period = d.pop("period")
        if not isinstance(period, str):
            raise TypeError(
                f"Expected type 'str' for field 'period', got '{type(period).__name__}'"
            )
        if not re.match(r"^\d{6}$", period):
            raise ValueError("period must be in the format YYYYMM")

        age = d.pop("age")
        if not isinstance(age, int):
            raise TypeError(
                f"Expected type 'int' for field 'age', got '{type(age).__name__}'"
            )
        if age < 0:
            raise ValueError("age must be a non-negative integer")

        employment_status = IncomeRequestEmploymentStatus(d.pop("employment_status"))

        income_month = d.pop("income_month")
        if not isinstance(income_month, (float, int)):
            raise TypeError(
                f"Expected type 'float' for field 'income_month', got '{type(income_month).__name__}'"
            )
        if income_month < 0:
            raise ValueError("income_month must be a non-negative float")

        income_request = cls(
            customer_id=customer_id,
            period=period,
            age=age,
            employment_status=employment_status,
            income_month=income_month,
        )

        income_request.additional_properties = d
        return income_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
